CREATE PROCEDURE fun2(IN title VARCHAR(255))
  BEGIN
SELECT a.*,b.itemDesc from tbitem a
LEFT JOIN tbitemdesc b on a.id=b.itemId
WHERE a.title like concat('%',title,'%');
END;
