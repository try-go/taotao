CREATE PROCEDURE fun3(IN id INT)
  BEGIN
SELECT a.*,b.itemDesc,d.paramData from tbitem a
LEFT JOIN tbitemdesc b on a.id=b.itemId
LEFT JOIN tbitemcat c ON c.id=a.cid
LEFT JOIN tbitemparam d on d.itemCatId=c.id
WHERE a.id=id;
END;
