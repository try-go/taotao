CREATE PROCEDURE fun9(IN page INT)
  BEGIN
declare pageStart int default 0;
SET pageStart = (page-1)*5;
SELECT * from tbitem limit pageStart,5;
END;
