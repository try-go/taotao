CREATE PROCEDURE fun1(IN id INT)
  BEGIN
SELECT a.*,b.itemDesc from tbitem a
LEFT JOIN tbitemdesc b on a.id=b.itemId
WHERE a.id=id;
END;
