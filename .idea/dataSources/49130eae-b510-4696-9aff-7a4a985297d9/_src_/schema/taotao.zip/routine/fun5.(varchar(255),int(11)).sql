CREATE PROCEDURE fun5(IN name VARCHAR(255), IN price INT)
  BEGIN
SELECT a.* FROM tbitem a
LEFT JOIN tbitemcat c ON c.id=a.cid
WHERE c.name=name and a.price >price;
END;
