CREATE PROCEDURE fun4(IN id INT)
  BEGIN
SELECT a.title,c.name from tbitem a
LEFT JOIN tbitemcat c ON c.id=a.cid
WHERE a.id=id;
END;
